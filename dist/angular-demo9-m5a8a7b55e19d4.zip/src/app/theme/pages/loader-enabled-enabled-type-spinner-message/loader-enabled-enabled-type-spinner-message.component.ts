import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../helpers';
import { ScriptLoaderService } from '../../../_services/script-loader.service';


@Component({
selector: ".m-grid__item.m-grid__item--fluid.m-grid.m-grid--hor-desktop.m-grid--desktop.m-body",
templateUrl: "./loader-enabled-enabled-type-spinner-message.component.html",
encapsulation: ViewEncapsulation.None,
})
export class LoaderEnabledEnabledTypeSpinnerMessageComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}