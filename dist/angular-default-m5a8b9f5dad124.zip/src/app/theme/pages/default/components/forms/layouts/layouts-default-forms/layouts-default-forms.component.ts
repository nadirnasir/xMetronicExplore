import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
selector: "app-layouts-default-forms",
templateUrl: "./layouts-default-forms.component.html",
encapsulation: ViewEncapsulation.None,
})
export class LayoutsDefaultFormsComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}