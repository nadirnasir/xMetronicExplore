import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-icons-socicons",
templateUrl: "./icons-socicons.component.html",
encapsulation: ViewEncapsulation.None,
})
export class IconsSociconsComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}