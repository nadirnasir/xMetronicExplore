import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-buttons-group",
templateUrl: "./buttons-group.component.html",
encapsulation: ViewEncapsulation.None,
})
export class ButtonsGroupComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}