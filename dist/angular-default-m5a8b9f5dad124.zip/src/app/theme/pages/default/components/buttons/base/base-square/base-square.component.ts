import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
selector: "app-base-square",
templateUrl: "./base-square.component.html",
encapsulation: ViewEncapsulation.None,
})
export class BaseSquareComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}