import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
selector: "app-base-default",
templateUrl: "./base-default.component.html",
encapsulation: ViewEncapsulation.None,
})
export class BaseDefaultComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}