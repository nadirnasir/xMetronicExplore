import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-base-spinners",
templateUrl: "./base-spinners.component.html",
encapsulation: ViewEncapsulation.None,
})
export class BaseSpinnersComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}