import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
selector: "app-controls-checkbox-radio",
templateUrl: "./controls-checkbox-radio.component.html",
encapsulation: ViewEncapsulation.None,
})
export class ControlsCheckboxRadioComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}