import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-base-scrollable",
templateUrl: "./base-scrollable.component.html",
encapsulation: ViewEncapsulation.None,
})
export class BaseScrollableComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}