import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
selector: "app-controls-input-group",
templateUrl: "./controls-input-group.component.html",
encapsulation: ViewEncapsulation.None,
})
export class ControlsInputGroupComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}