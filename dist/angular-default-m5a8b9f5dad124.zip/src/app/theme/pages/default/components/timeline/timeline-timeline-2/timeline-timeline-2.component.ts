import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-timeline-timeline-2",
templateUrl: "./timeline-timeline-2.component.html",
encapsulation: ViewEncapsulation.None,
})
export class TimelineTimeline2Component implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}