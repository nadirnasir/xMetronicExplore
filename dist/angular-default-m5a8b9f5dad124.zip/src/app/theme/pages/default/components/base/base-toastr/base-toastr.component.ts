import { Component, OnInit, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { Helpers } from '../../../../../../helpers';
import { ScriptLoaderService } from '../../../../../../_services/script-loader.service';


@Component({
selector: "app-base-toastr",
templateUrl: "./base-toastr.component.html",
encapsulation: ViewEncapsulation.None,
})
export class BaseToastrComponent implements OnInit, AfterViewInit {


constructor(private _script: ScriptLoaderService)  {

}
ngOnInit()  {

}
ngAfterViewInit()  {
this._script.loadScripts('app-base-toastr',
['assets/demo/default/custom/components/base/toastr.js']);

}

}