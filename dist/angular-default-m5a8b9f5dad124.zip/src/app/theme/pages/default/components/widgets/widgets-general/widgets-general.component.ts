import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-widgets-general",
templateUrl: "./widgets-general.component.html",
encapsulation: ViewEncapsulation.None,
})
export class WidgetsGeneralComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}