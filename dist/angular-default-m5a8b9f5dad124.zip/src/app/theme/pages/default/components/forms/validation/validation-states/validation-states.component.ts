import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
selector: "app-validation-states",
templateUrl: "./validation-states.component.html",
encapsulation: ViewEncapsulation.None,
})
export class ValidationStatesComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}