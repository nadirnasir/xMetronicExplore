import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../../helpers';


@Component({
selector: "app-base-pill",
templateUrl: "./base-pill.component.html",
encapsulation: ViewEncapsulation.None,
})
export class BasePillComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}