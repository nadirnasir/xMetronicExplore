import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Helpers } from '../../../../../../helpers';


@Component({
selector: "app-base-alerts",
templateUrl: "./base-alerts.component.html",
encapsulation: ViewEncapsulation.None,
})
export class BaseAlertsComponent implements OnInit {


constructor()  {

}
ngOnInit()  {

}

}